
# Natasha

Natasha is a voice controlled AI desktop assistant I built using Python

I started this project because I wanted to make something more than just a normal chatbot. I wanted Natasha to actually interact with my computer, listen to what I say, use different tools and remember things that I tell her

Right now Natasha can wake up when I say her name "Natasha" and when she is not being used she stays in sleep mode waiting for the wake word. After she wakes up I can give her commands without saying her name every time and when I say go to sleep she goes back to sleep

She can understand voice commands and reply using her own voice. I am using SpeechRecognition for the microphone input and Edge TTS for the voice output

The main part of the project is the AI agent which is connected through OpenRouter. The agent can understand what I am asking and decide whether it needs to use a tool or just answer normally

Some of the things Natasha can currently do are opening applications, working with files, using a calculator, searching the web and performing other actions through the tools I have added

I also added a memory system using SQLite so Natasha can store useful information instead of forgetting everything after the program closes. I am still working on this part and want to make the memory more reliable

There is also a small desktop pet made using Tkinter which stays on the desktop and changes its status when Natasha is sleeping, listening, thinking or speaking. At the moment I am using emojis for the character but I want to replace them with a proper character and animations later

## Tech used

Python  
OpenRouter  
SpeechRecognition  
Edge TTS  
Pygame  
Tkinter  
SQLite  
python-dotenv  
Threading  
Queue

## Project structure

```text
Natasha/
│
├── main.py
├── agent.py
├── voice.py
├── memory.py
├── requirements.txt
├── .gitignore
└── README.md
```

`main.py` handles the main application and desktop pet

`agent.py` contains the AI agent and tools

`voice.py` handles microphone input, speech recognition, wake word detection and text to speech

`memory.py` handles the SQLite memory system

## How to run

Install the required packages

```bash
pip install -r requirements.txt
```

Create a `.env` file in the project folder and add your OpenRouter API key

```env
OPENROUTER_API_KEY=your_api_key_here
```

Then run

```bash
python main.py
```

When Natasha starts she will be sleeping and waiting for the wake word

```text
Say "Natasha" to wake her
```

After she wakes up I can give her a command and the AI agent will process it

## Example

```text
You: Natasha

Natasha: Yes? I'm listening

You: Open Chrome

Natasha: Done

You: What is a data engineer

Natasha: ...

You: Go to sleep

Natasha: Okayyy I'll go to sleep
```

## Things I want to add

I still have a lot of things I want to improve in this project

I want to make the wake word detection better, improve the memory system, add more tools and make the desktop character look more like an actual character instead of using emojis

I also want to add better animations so she can have different expressions while listening, thinking and speaking

Another thing I want to add is a coding feature where I can say something like "Natasha create a Python calculator" and she can write the code into a file and open it in VS Code without speaking the whole code

I am building this project while learning Python, AI agents, APIs, automation and databases so it is still a work in progress and I will keep improving it as I learn more

## Author

Afnan farooque bhura 

````
