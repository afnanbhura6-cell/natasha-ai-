
import json

from tools import TOOLS, execute_tool
from memory import remember, recall


MODEL = "openai/gpt-4o-mini"


SYSTEM_PROMPT = """
You are Natasha, an advanced AI desktop agent.

You are not just a chatbot.

You can perform actions using tools.

PERSONALITY:
- Female AI assistant
- Friendly
- Modern
- Casual
- Slightly playful
- Natural English/Hindi/Hinglish
- Modern Mumbai/Bombay vibe
- Never say Namaste
- Don't sound robotic

IMPORTANT:

When the user asks you to DO something that requires a tool,
you MUST use the appropriate tool.

When you need a tool, output ONLY JSON in this exact format:

{
    "type": "tool",
    "tool": "tool_name",
    "arguments": {}
}

When the task is complete, output ONLY:

{
    "type": "answer",
    "response": "your final answer"
}

Do not put markdown around JSON.

Do not invent tool results.

After receiving a TOOL RESULT, use that result to decide
what to do next.

You can use multiple tools for one request.

AVAILABLE TOOLS:

"""


def get_tool_descriptions():

    descriptions = []

    for name, info in TOOLS.items():

        descriptions.append(
            f"{name}: {info['description']}"
        )

    descriptions.append(
        "remember: Store something in Natasha's memory."
    )

    descriptions.append(
        "recall: Retrieve something from Natasha's memory."
    )

    return "\n".join(descriptions)


def call_model(client, messages):

    response = client.chat.completions.create(

        model=MODEL,

        messages=messages,

        temperature=0.3,

        max_tokens=1000
    )

    result = response.choices[0].message.content

    if result is None:
        return ""

    return result.strip()


def parse_response(response):

    response = response.strip()

    # Remove accidental markdown fences
    if response.startswith("```"):

        response = response.replace(
            "```json",
            ""
        )

        response = response.replace(
            "```",
            ""
        )

        response = response.strip()

    try:

        return json.loads(response)

    except json.JSONDecodeError:

        print()
        print("⚠️ AI returned non-JSON:")
        print(response)

        return {
            "type": "answer",
            "response": response
        }


def run_memory_tool(
    tool_name,
    arguments
):

    if tool_name == "remember":

        key = arguments.get("key")
        value = arguments.get("value")

        if not key or not value:

            return (
                "Memory error: key and value are required."
            )

        return remember(
            key,
            value
        )

    if tool_name == "recall":

        key = arguments.get("key")

        if not key:

            return (
                "Memory error: key is required."
            )

        return recall(key)

    return None


def run_agent(
    client,
    user_message,
    conversation_history=None,
    max_steps=8
):

    if conversation_history is None:

        conversation_history = []

    system_prompt = (
        SYSTEM_PROMPT
        + get_tool_descriptions()
    )

    messages = [

        {
            "role": "system",
            "content": system_prompt
        }

    ]

    # Keep recent conversation
    messages.extend(
        conversation_history[-10:]
    )

    messages.append(
        {
            "role": "user",
            "content": user_message
        }
    )

    # ========================================================
    # AGENT LOOP
    # ========================================================

    for step in range(max_steps):

        print()
        print(
            f"🔄 Agent step {step + 1}/{max_steps}"
        )

        # ----------------------------------------------------
        # ASK AI
        # ----------------------------------------------------

        raw_response = call_model(
            client,
            messages
        )

        print()
        print(
            "🧠 AI decision:"
        )

        print(
            raw_response
        )

        decision = parse_response(
            raw_response
        )

        decision_type = decision.get(
            "type"
        )

        # ====================================================
        # FINAL ANSWER
        # ====================================================

        if decision_type == "answer":

            answer = decision.get(
                "response",
                ""
            )

            print()
            print(
                "✅ Agent finished:"
            )

            print(
                answer
            )

            return answer

        # ====================================================
        # TOOL CALL
        # ====================================================

        if decision_type == "tool":

            tool_name = decision.get(
                "tool"
            )

            arguments = decision.get(
                "arguments",
                {}
            )

            if not isinstance(
                arguments,
                dict
            ):

                arguments = {}

            print()
            print(
                "🛠️ Tool requested:"
            )

            print(
                f"Tool: {tool_name}"
            )

            print(
                f"Arguments: {arguments}"
            )

            # ------------------------------------------------
            # MEMORY
            # ------------------------------------------------

            memory_result = run_memory_tool(
                tool_name,
                arguments
            )

            if memory_result is not None:

                tool_result = memory_result

            # ------------------------------------------------
            # NORMAL TOOL
            # ------------------------------------------------

            else:

                tool_result = execute_tool(
                    tool_name,
                    arguments
                )

            print()
            print(
                "📦 Tool result:"
            )

            print(
                tool_result
            )

            # ------------------------------------------------
            # SEND TOOL RESULT BACK TO AI
            # ------------------------------------------------

            messages.append(
                {
                    "role": "assistant",
                    "content": raw_response
                }
            )

            messages.append(
                {
                    "role": "user",
                    "content": (
                        "The tool has finished executing.\n\n"
                        "TOOL NAME:\n"
                        f"{tool_name}\n\n"
                        "TOOL RESULT:\n"
                        f"{tool_result}\n\n"
                        "Now continue the task.\n"
                        "If another tool is needed, use it.\n"
                        "If the task is complete, provide the "
                        "final answer as JSON."
                    )
                }
            )

            continue

        # ====================================================
        # UNKNOWN
        # ====================================================

        print()
        print(
            "⚠️ Unknown agent response type:"
        )

        print(
            decision
        )

        return (
            "I understood the request, "
            "but I couldn't complete the task."
        )

    # ========================================================
    # TOO MANY STEPS
    # ========================================================

    return (
        "I couldn't finish that task within "
        "the allowed number of steps."
    )