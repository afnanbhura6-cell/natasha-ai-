import tkinter as tk


class DesktopPet:

    def __init__(self):

        self.root = tk.Tk()

        self.root.title("Natasha")

        # Remove normal Windows title bar
        self.root.overrideredirect(True)

        # Keep Natasha above other windows
        self.root.attributes("-topmost", True)

        # Transparent background
        self.root.attributes(
            "-transparentcolor",
            "black"
        )

        self.root.configure(
            bg="black"
        )

        # Window size
        self.width = 250
        self.height = 300

        # Start near bottom-right
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        x = screen_width - self.width - 40
        y = screen_height - self.height - 80

        self.root.geometry(
            f"{self.width}x{self.height}+{x}+{y}"
        )

        # ====================================================
        # CHARACTER
        # ====================================================

        self.character = tk.Label(
            self.root,
            text="👩🏻",
            font=("Segoe UI Emoji", 110),
            bg="black"
        )

        self.character.pack(
            pady=(20, 0)
        )

        # ====================================================
        # NAME
        # ====================================================

        self.name = tk.Label(
            self.root,
            text="Natasha",
            font=("Segoe UI", 18, "bold"),
            fg="white",
            bg="black"
        )

        self.name.pack()

        # ====================================================
        # STATUS
        # ====================================================

        self.status = tk.Label(
            self.root,
            text="● Online",
            font=("Segoe UI", 10),
            fg="#8EF0A7",
            bg="black"
        )

        self.status.pack(
            pady=5
        )

        # ====================================================
        # DRAGGING
        # ====================================================

        self.character.bind(
            "<Button-1>",
            self.start_drag
        )

        self.character.bind(
            "<B1-Motion>",
            self.drag
        )

        self.name.bind(
            "<Button-1>",
            self.start_drag
        )

        self.name.bind(
            "<B1-Motion>",
            self.drag
        )

        # Right click closes
        self.root.bind(
            "<Button-3>",
            self.close
        )

        # Start idle animation
        self.blink()

    # ========================================================
    # DRAG
    # ========================================================

    def start_drag(self, event):

        self.drag_x = event.x
        self.drag_y = event.y

    def drag(self, event):

        x = self.root.winfo_x() + event.x - self.drag_x
        y = self.root.winfo_y() + event.y - self.drag_y

        self.root.geometry(
            f"+{x}+{y}"
        )

    # ========================================================
    # BLINK
    # ========================================================

    def blink(self):

        # Close eyes
        self.character.config(
            text="👩🏻"
        )

        self.root.after(
            4000,
            self.blink_again
        )

    def blink_again(self):

        # Small animation
        self.character.config(
            text="😌"
        )

        self.root.after(
            250,
            self.blink
        )

    # ========================================================
    # STATUS
    # ========================================================

    def set_status(self, text):

        self.status.config(
            text=text
        )

    # ========================================================
    # CLOSE
    # ========================================================

    def close(self, event=None):

        self.root.destroy()

    # ========================================================
    # RUN
    # ========================================================

    def run(self):

        self.root.mainloop()


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    pet = DesktopPet()

    pet.run()