import os
import threading
import queue
import tkinter as tk
import pygame

from dotenv import load_dotenv
from openai import OpenAI

from agent import run_agent
from memory import initialize_memory
from voice import listen, speak, wait_for_wake_word


# ============================================================
# SETUP
# ============================================================

load_dotenv()

API_KEY = os.getenv("OPENROUTER_API_KEY")

if not API_KEY:
    raise ValueError(
        "OPENROUTER_API_KEY not found in .env"
    )


client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=API_KEY
)


pygame.mixer.init()

gui_queue = queue.Queue()


# ============================================================
# DESKTOP PET
# ============================================================

class DesktopPet:

    def __init__(self):

        self.root = tk.Tk()

        self.root.title("Natasha")

        self.root.overrideredirect(True)

        self.root.attributes(
            "-topmost",
            True
        )

        self.root.configure(
            bg="black"
        )

        # ----------------------------------------------------
        # TRANSPARENT BACKGROUND
        # ----------------------------------------------------

        try:
            self.root.attributes(
                "-transparentcolor",
                "black"
            )
        except Exception:
            pass

        # ----------------------------------------------------
        # WINDOW
        # ----------------------------------------------------

        self.width = 280
        self.height = 350

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        x = (
            screen_width
            - self.width
            - 40
        )

        y = (
            screen_height
            - self.height
            - 80
        )

        self.root.geometry(
            f"{self.width}x{self.height}+{x}+{y}"
        )

        # ----------------------------------------------------
        # CHARACTER
        # ----------------------------------------------------

        self.character = tk.Label(
            self.root,
            text="😴",
            font=(
                "Segoe UI Emoji",
                100
            ),
            bg="black"
        )

        self.character.pack(
            pady=(15, 0)
        )

        # ----------------------------------------------------
        # NAME
        # ----------------------------------------------------

        self.name = tk.Label(
            self.root,
            text="Natasha",
            font=(
                "Segoe UI",
                18,
                "bold"
            ),
            fg="white",
            bg="black"
        )

        self.name.pack()

        # ----------------------------------------------------
        # STATUS
        # ----------------------------------------------------

        self.status = tk.Label(
            self.root,
            text="● Sleeping",
            font=(
                "Segoe UI",
                10
            ),
            fg="#8EF0A7",
            bg="black"
        )

        self.status.pack(
            pady=5
        )

        # ----------------------------------------------------
        # DRAG
        # ----------------------------------------------------

        self.character.bind(
            "<Button-1>",
            self.start_drag
        )

        self.character.bind(
            "<B1-Motion>",
            self.drag
        )

        self.name.bind(
            "<Button-1>",
            self.start_drag
        )

        self.name.bind(
            "<B1-Motion>",
            self.drag
        )

        # ----------------------------------------------------
        # RIGHT CLICK TO CLOSE
        # ----------------------------------------------------

        self.root.bind(
            "<Button-3>",
            self.close
        )

        # ----------------------------------------------------
        # GUI QUEUE
        # ----------------------------------------------------

        self.root.after(
            100,
            self.process_queue
        )

    # ========================================================
    # GUI QUEUE
    # ========================================================

    def process_queue(self):

        try:

            while True:

                command = gui_queue.get_nowait()

                if command == "listen":

                    self.show_listening()

                elif command == "think":

                    self.show_thinking()

                elif command == "speak":

                    self.show_speaking()

                elif command == "happy":

                    self.show_happy()

                elif command == "normal":

                    self.show_normal()

                elif command == "sleep":

                    self.show_sleeping()

                elif command == "close":

                    self.close()

        except queue.Empty:

            pass

        self.root.after(
            100,
            self.process_queue
        )

    # ========================================================
    # DRAG
    # ========================================================

    def start_drag(self, event):

        self.drag_x = event.x
        self.drag_y = event.y

    def drag(self, event):

        x = (
            self.root.winfo_x()
            + event.x
            - self.drag_x
        )

        y = (
            self.root.winfo_y()
            + event.y
            - self.drag_y
        )

        self.root.geometry(
            f"+{x}+{y}"
        )

    # ========================================================
    # EXPRESSIONS
    # ========================================================

    def show_sleeping(self):

        self.character.config(
            text="😴"
        )

        self.status.config(
            text="● Sleeping"
        )

    def show_normal(self):

        self.character.config(
            text="👩🏻"
        )

        self.status.config(
            text="● Awake"
        )

    def show_listening(self):

        self.character.config(
            text="👂"
        )

        self.status.config(
            text="🎤 Listening..."
        )

    def show_thinking(self):

        self.character.config(
            text="🤔"
        )

        self.status.config(
            text="🧠 Thinking..."
        )

    def show_speaking(self):

        self.character.config(
            text="😊"
        )

        self.status.config(
            text="🔊 Speaking..."
        )

    def show_happy(self):

        self.character.config(
            text="🥰"
        )

        self.status.config(
            text="✨ Natasha is awake"
        )

    # ========================================================
    # CLOSE
    # ========================================================

    def close(self, event=None):

        try:
            pygame.mixer.music.stop()
        except Exception:
            pass

        try:
            self.root.destroy()
        except Exception:
            pass


# ============================================================
# NATASHA WORKER
# ============================================================

def natasha_worker():

    print()
    print("=" * 60)
    print("🐾 NATASHA - AI AGENT")
    print("=" * 60)

    print("🎤 Voice: ON")
    print("🧠 Agent: ON")
    print("🛠️ Tools: ON")
    print("💾 Memory: ON")
    print("🖥️ Desktop Pet: ON")
    print("😴 Wake Word: ON")

    print("=" * 60)

    conversation_history = []

    # ========================================================
    # SLEEP / WAKE LOOP
    # ========================================================

    while True:

        # ====================================================
        # SLEEPING
        # ====================================================

        gui_queue.put(
            "sleep"
        )

        print()
        print("😴 Natasha is sleeping.")
        print("   Say 'Natasha' to wake her.")

        # ====================================================
        # WAIT FOR "NATASHA"
        # ====================================================

        wake_detected = wait_for_wake_word(
            gui_queue
        )

        if not wake_detected:

            continue

        # ====================================================
        # NATASHA WAKES UP
        # ====================================================

        print()
        print("✨ Natasha woke up!")

        gui_queue.put(
            "happy"
        )

        speak(
            "Yes? I'm listening.",
            gui_queue
        )

        # ====================================================
        # AWAKE CONVERSATION LOOP
        # ====================================================

        while True:

            # ------------------------------------------------
            # LISTEN
            # ------------------------------------------------

            user_message = listen(
                gui_queue
            )

            if not user_message:

                print(
                    "❓ I didn't hear anything."
                )

                continue

            command = (
                user_message
                .lower()
                .strip()
            )

            print(
                f"👤 You: {user_message}"
            )

            # ------------------------------------------------
            # GO TO SLEEP
            # ------------------------------------------------

            if command in [

                "bye",
                "goodbye",
                "exit",
                "quit",
                "sleep",
                "go to sleep",
                "you can sleep",
                "that's all",
                "thats all"

            ]:

                speak(
                    "Okayyy, I'll go to sleep. "
                    "Call me whenever you need me.",
                    gui_queue
                )

                gui_queue.put(
                    "sleep"
                )

                # Break the awake loop.
                # Natasha will now return to the
                # wake-word loop.

                break

            # ------------------------------------------------
            # THINKING
            # ------------------------------------------------

            gui_queue.put(
                "think"
            )

            try:

                print()
                print(
                    "🧠 Natasha is planning..."
                )

                answer = run_agent(
                    client,
                    user_message,
                    conversation_history
                )

                # --------------------------------------------
                # SAVE CONVERSATION
                # --------------------------------------------

                conversation_history.append(
                    {
                        "role": "user",
                        "content": user_message
                    }
                )

                conversation_history.append(
                    {
                        "role": "assistant",
                        "content": answer
                    }
                )

                # --------------------------------------------
                # SPEAK
                # --------------------------------------------

                if answer:

                    speak(
                        answer,
                        gui_queue
                    )

                else:

                    speak(
                        "Umm... my brain went blank 😂",
                        gui_queue
                    )

                # --------------------------------------------
                # STAY AWAKE
                # --------------------------------------------

                gui_queue.put(
                    "normal"
                )

                print()
                print(
                    "👀 Natasha is still awake."
                )
                print(
                    "   Say another command, "
                    "or say 'go to sleep'."
                )

            except Exception as error:

                print()
                print(
                    "❌ AGENT ERROR:"
                )

                print(error)

                speak(
                    "Ugh, something went wrong "
                    "with my brain. Give me a second.",
                    gui_queue
                )

                gui_queue.put(
                    "normal"
                )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    initialize_memory()

    pet = DesktopPet()

    worker_thread = threading.Thread(
        target=natasha_worker,
        daemon=True
    )

    worker_thread.start()

    pet.root.mainloop()