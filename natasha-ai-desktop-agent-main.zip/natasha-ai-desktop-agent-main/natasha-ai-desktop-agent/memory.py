import sqlite3
from pathlib import Path
from datetime import datetime


# ============================================================
# DATABASE LOCATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DB_FILE = BASE_DIR / "natasha_memory.db"


# ============================================================
# DATABASE CONNECTION
# ============================================================

def get_connection():

    connection = sqlite3.connect(
        str(DB_FILE)
    )

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_key TEXT UNIQUE NOT NULL,
            memory_value TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )

    connection.commit()

    return connection


# ============================================================
# INITIALIZE
# ============================================================

def initialize_memory():

    connection = get_connection()

    connection.close()

    print(
        f"🧠 Memory database: {DB_FILE}"
    )


# ============================================================
# REMEMBER
# ============================================================

def remember(
    key,
    value
):

    connection = get_connection()

    cursor = connection.cursor()

    now = datetime.now().isoformat()

    cursor.execute(
        """
        INSERT INTO memories
        (memory_key, memory_value, created_at)

        VALUES (?, ?, ?)

        ON CONFLICT(memory_key)
        DO UPDATE SET
            memory_value = excluded.memory_value,
            created_at = excluded.created_at
        """,
        (
            key,
            value,
            now
        )
    )

    connection.commit()

    connection.close()

    print(
        f"🧠 Remembered: {key} = {value}"
    )

    return (
        f"Remembered '{key}'."
    )


# ============================================================
# RECALL ONE MEMORY
# ============================================================

def recall(key):

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT memory_value
        FROM memories
        WHERE memory_key = ?
        """,
        (key,)
    )

    row = cursor.fetchone()

    connection.close()

    if row is None:

        return (
            f"I don't have a memory stored "
            f"for '{key}'."
        )

    return row[0]


# ============================================================
# GET ALL MEMORIES
# ============================================================

def get_all_memories():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT memory_key, memory_value
        FROM memories
        ORDER BY id ASC
        """
    )

    rows = cursor.fetchall()

    connection.close()

    return rows


# ============================================================
# MEMORY TEXT FOR AI
# ============================================================

def get_memory_context():

    memories = get_all_memories()

    if not memories:

        return "No long-term memories stored yet."

    lines = []

    for key, value in memories:

        lines.append(
            f"- {key}: {value}"
        )

    return "\n".join(lines)