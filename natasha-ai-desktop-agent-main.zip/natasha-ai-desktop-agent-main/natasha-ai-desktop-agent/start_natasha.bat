@echo off

cd /d "%~dp0"

"C:\Users\afnan\AppData\Local\Microsoft\WindowsApps\python3.12.exe" "%~dp0main.py"

echo.
echo Natasha has stopped.
pause