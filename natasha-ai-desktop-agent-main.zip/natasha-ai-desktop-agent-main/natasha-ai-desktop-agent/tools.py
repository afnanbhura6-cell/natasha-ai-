import os
import subprocess
import requests
import ast
import operator


# ============================================================
# OPEN APPLICATION
# ============================================================

def open_application(app_name):

    apps = {

        "notepad": "notepad.exe",

        "calculator": "calc.exe",

        "calc": "calc.exe",

        "chrome": "chrome.exe",

        "google chrome": "chrome.exe",

        "edge": "msedge.exe",

        "microsoft edge": "msedge.exe",

        "vscode": "code",

        "vs code": "code",

        "visual studio code": "code"

    }

    app_name = str(
        app_name
    ).lower().strip()

    if app_name not in apps:

        return (
            f"I don't know how to open '{app_name}'. "
            f"Available applications: "
            f"{', '.join(apps.keys())}"
        )

    try:

        subprocess.Popen(
            apps[app_name]
        )

        return (
            f"Successfully opened {app_name}."
        )

    except Exception as error:

        return (
            f"Could not open {app_name}: {error}"
        )


# ============================================================
# LIST FILES
# ============================================================

def list_files(folder_path="."):

    try:

        folder_path = os.path.abspath(
            folder_path
        )

        print()
        print(
            f"📁 Reading folder: {folder_path}"
        )

        if not os.path.exists(
            folder_path
        ):

            return (
                f"Folder does not exist: "
                f"{folder_path}"
            )

        if not os.path.isdir(
            folder_path
        ):

            return (
                f"This is not a folder: "
                f"{folder_path}"
            )

        files = os.listdir(
            folder_path
        )

        if not files:

            return "The folder is empty."

        result = []

        for filename in sorted(files):

            full_path = os.path.join(
                folder_path,
                filename
            )

            if os.path.isdir(
                full_path
            ):

                result.append(
                    f"[FOLDER] {filename}"
                )

            else:

                result.append(
                    f"[FILE] {filename}"
                )

        return "\n".join(
            result
        )

    except Exception as error:

        return (
            f"Could not list files: {error}"
        )


# ============================================================
# READ FILE
# ============================================================

def read_file(file_path):

    try:

        file_path = os.path.abspath(
            file_path
        )

        if not os.path.exists(
            file_path
        ):

            return (
                f"File not found: {file_path}"
            )

        if not os.path.isfile(
            file_path
        ):

            return (
                f"This is not a file: {file_path}"
            )

        with open(
            file_path,
            "r",
            encoding="utf-8"
        ) as file:

            content = file.read()

        if len(content) > 15000:

            content = content[:15000]

            content += (
                "\n\n[File truncated]"
            )

        return content

    except UnicodeDecodeError:

        return (
            "I cannot read this file as text."
        )

    except Exception as error:

        return (
            f"Could not read file: {error}"
        )


# ============================================================
# CREATE FILE
# ============================================================

def create_file(
    file_path,
    content
):

    try:

        file_path = os.path.abspath(
            file_path
        )

        folder = os.path.dirname(
            file_path
        )

        if folder:

            os.makedirs(
                folder,
                exist_ok=True
            )

        with open(
            file_path,
            "w",
            encoding="utf-8"
        ) as file:

            file.write(
                content
            )

        return (
            f"Successfully created "
            f"{file_path}"
        )

    except Exception as error:

        return (
            f"Could not create file: {error}"
        )


# ============================================================
# WEB SEARCH
# ============================================================

def search_web(query):

    try:

        response = requests.get(

            "https://api.duckduckgo.com/",

            params={

                "q": query,

                "format": "json",

                "no_html": 1,

                "skip_disambig": 1

            },

            timeout=10
        )

        response.raise_for_status()

        data = response.json()

        abstract = data.get(
            "AbstractText",
            ""
        )

        if abstract:

            return abstract

        results = []

        for item in data.get(
            "RelatedTopics",
            []
        ):

            if isinstance(
                item,
                dict
            ):

                text = item.get(
                    "Text"
                )

                if text:

                    results.append(
                        text
                    )

        if results:

            return "\n".join(
                results[:5]
            )

        return (
            "No useful search results found."
        )

    except Exception as error:

        return (
            f"Web search failed: {error}"
        )


# ============================================================
# SAFE CALCULATOR
# ============================================================

_ALLOWED_OPERATORS = {

    ast.Add: operator.add,

    ast.Sub: operator.sub,

    ast.Mult: operator.mul,

    ast.Div: operator.truediv,

    ast.Mod: operator.mod,

    ast.Pow: operator.pow,

    ast.USub: operator.neg,

    ast.UAdd: operator.pos

}


def _calculate_node(node):

    if isinstance(
        node,
        ast.Constant
    ):

        if isinstance(
            node.value,
            (int, float)
        ):

            return node.value

        raise ValueError(
            "Only numbers are allowed."
        )

    if isinstance(
        node,
        ast.BinOp
    ):

        operation = _ALLOWED_OPERATORS.get(
            type(node.op)
        )

        if operation is None:

            raise ValueError(
                "Operator not allowed."
            )

        left = _calculate_node(
            node.left
        )

        right = _calculate_node(
            node.right
        )

        return operation(
            left,
            right
        )

    if isinstance(
        node,
        ast.UnaryOp
    ):

        operation = _ALLOWED_OPERATORS.get(
            type(node.op)
        )

        if operation is None:

            raise ValueError(
                "Operator not allowed."
            )

        value = _calculate_node(
            node.operand
        )

        return operation(
            value
        )

    raise ValueError(
        "Invalid mathematical expression."
    )


def calculate(expression):

    try:

        tree = ast.parse(
            expression,
            mode="eval"
        )

        result = _calculate_node(
            tree.body
        )

        return str(result)

    except Exception as error:

        return (
            f"Could not calculate: {error}"
        )


# ============================================================
# TOOL REGISTRY
# ============================================================

TOOLS = {

    "open_application": {

        "function": open_application,

        "description":
            "Open a Windows application. "
            "Argument: app_name"

    },

    "list_files": {

        "function": list_files,

        "description":
            "List files and folders. "
            "Argument: folder_path. "
            "Use '.' for the current project folder."

    },

    "read_file": {

        "function": read_file,

        "description":
            "Read a text file. "
            "Argument: file_path"

    },

    "create_file": {

        "function": create_file,

        "description":
            "Create a text file. "
            "Arguments: file_path and content"

    },

    "search_web": {

        "function": search_web,

        "description":
            "Search the web. "
            "Argument: query"

    },

    "calculate": {

        "function": calculate,

        "description":
            "Perform a mathematical calculation. "
            "Argument: expression"

    }

}


# ============================================================
# EXECUTE TOOL
# ============================================================

def execute_tool(
    tool_name,
    arguments
):

    print()
    print(
        f"⚙️ Executing: {tool_name}"
    )

    print(
        f"📌 Arguments: {arguments}"
    )

    if tool_name not in TOOLS:

        return (
            f"Unknown tool: {tool_name}"
        )

    try:

        function = TOOLS[
            tool_name
        ][
            "function"
        ]

        result = function(
            **arguments
        )

        return str(
            result
        )

    except TypeError as error:

        return (
            f"Invalid arguments for "
            f"{tool_name}: {error}"
        )

    except Exception as error:

        return (
            f"Tool {tool_name} failed: "
            f"{error}"
        )