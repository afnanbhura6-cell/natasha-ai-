import asyncio
import os
import tempfile

import edge_tts
import pygame
import speech_recognition as sr


VOICE = "hi-IN-SwaraNeural"
WAKE_WORD = "natasha"


recognizer = sr.Recognizer()

recognizer.pause_threshold = 1.3
recognizer.non_speaking_duration = 0.5


# ============================================================
# TEXT TO SPEECH
# ============================================================

async def generate_voice(text, filename):

    communicate = edge_tts.Communicate(
        text=text,
        voice=VOICE,
        rate="+0%",
        volume="+0%",
        pitch="+0Hz"
    )

    await communicate.save(filename)


def speak(text, gui_queue=None):

    print()
    print(f"🐾 Natasha: {text}")

    if gui_queue:
        gui_queue.put("speak")

    filename = None

    try:

        temp_file = tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".mp3"
        )

        filename = temp_file.name
        temp_file.close()

        asyncio.run(
            generate_voice(
                text,
                filename
            )
        )

        pygame.mixer.music.stop()

        pygame.mixer.music.load(filename)

        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():

            pygame.time.Clock().tick(20)

        pygame.mixer.music.unload()

    except Exception as error:

        print("VOICE ERROR:", error)

    finally:

        if filename:

            try:
                os.remove(filename)

            except Exception:
                pass

        if gui_queue:
            gui_queue.put("normal")


# ============================================================
# WAKE WORD
# ============================================================

def wait_for_wake_word(gui_queue=None):

    print()
    print("😴 Natasha is sleeping...")
    print("   Say 'Natasha' to wake me.")
    print()

    while True:

        try:

            with sr.Microphone() as source:

                if gui_queue:
                    gui_queue.put("normal")

                # Small adjustment for background noise
                recognizer.adjust_for_ambient_noise(
                    source,
                    duration=0.3
                )

                print("👂 Waiting for wake word...")

                # Listen for a short phrase
                audio = recognizer.listen(
                    source,
                    timeout=None,
                    phrase_time_limit=4
                )

            # Try English first
            try:

                text = recognizer.recognize_google(
                    audio,
                    language="en-IN"
                ).lower()

                print(f"👂 Heard: {text}")

                if WAKE_WORD in text:
                    return True

            except sr.UnknownValueError:
                pass

            # Try Hindi recognition too
            try:

                text = recognizer.recognize_google(
                    audio,
                    language="hi-IN"
                ).lower()

                print(f"👂 Heard: {text}")

                if WAKE_WORD in text:
                    return True

            except sr.UnknownValueError:
                pass

        except Exception as error:

            print(
                "WAKE WORD ERROR:",
                error
            )


# ============================================================
# NORMAL VOICE INPUT
# ============================================================

def listen(gui_queue=None):

    try:

        with sr.Microphone() as source:

            if gui_queue:
                gui_queue.put("listen")

            print()
            print("🎤 Listening...")

            recognizer.adjust_for_ambient_noise(
                source,
                duration=0.5
            )

            audio = recognizer.listen(
                source
            )

        print("🧠 Understanding...")

        # ----------------------------------------------------
        # English
        # ----------------------------------------------------

        try:

            text = recognizer.recognize_google(
                audio,
                language="en-IN"
            )

            print(
                f"👤 You: {text}"
            )

            return text

        except sr.UnknownValueError:

            pass

        # ----------------------------------------------------
        # Hindi
        # ----------------------------------------------------

        try:

            text = recognizer.recognize_google(
                audio,
                language="hi-IN"
            )

            print(
                f"👤 You: {text}"
            )

            return text

        except sr.UnknownValueError:

            print(
                "❓ I couldn't understand you."
            )

            return ""

    except Exception as error:

        print()
        print(
            "MICROPHONE ERROR:",
            error
        )

        return ""
        